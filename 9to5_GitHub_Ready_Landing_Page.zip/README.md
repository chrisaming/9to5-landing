
# 9 TO 5 – Neon Landing Page 🚀

Welcome to the official landing page for **9 TO 5: Stream. Engage. Earn.**

This neon-themed site is fully responsive, dark-mode ready, and perfect for GitHub Pages hosting.

## 🚀 How to Deploy with GitHub Pages

1. Create a new GitHub repository (e.g. `9to5-landing`)
2. Upload the contents of this folder (not the .zip itself)
3. Go to your repo's **Settings > Pages**
4. Under "Source", select:
   - **Branch**: `main`
   - **Folder**: `/ (root)`
5. Click "Save"

✅ Your site will go live at `https://yourusername.github.io/9to5-landing`

---

## 🧠 About the App

**9 TO 5** is a content-driven creator network focused on:
- 🔁 Real engagement: reactions, critiques, collaboration
- 🎵 Music, Reels, Videos, and Artwork
- 💰 Fair monetization through user actions

